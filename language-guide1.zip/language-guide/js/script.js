jQuery(function($) {
 
    $("a.topopup").click(function() {
        loading(); // loading
        setTimeout(function() { // then show popup, deley in .5 second
            loadPopup(); // function show popup 
        }, 500); // .5 second
        return false;
    });
 
    /* event for close the popup */
    $("div.close").hover(
        function() {
            $('span.ecs_tooltip').show();
        },
        function() {
            $('span.ecs_tooltip').hide();
        }
    );
 
    $("div.close").click(function() {
        disablePopup(); // function close pop up
    });
 
    $(this).keyup(function(event) {
        if (event.which == 27) { // 27 is 'Ecs' in the keyboard
            disablePopup(); // function close pop up
        }
    });
 
    $("div#backgroundPopup").click(function() {
        disablePopup(); // function close pop up
    });
 
    $('a.livebox').click(function() {
        alert('Hello World!');
        return false;
    });
 
    /************** start: functions. **************/
    function loading() {
        $("div.loader").show();
    }
 
    function closeloading() {
        $("div.loader").fadeOut('normal');
    }
 
    var popupStatus = 0; // set value
 
    function loadPopup() {
        if (popupStatus == 0) { // if value is 0, show popup
            closeloading(); // fadeout loading
            $("#toPopup").fadeIn(0500); // fadein popup div
            $("#backgroundPopup").css("opacity", "0.2"); // css opacity, supports IE7, IE8
            $("#backgroundPopup").fadeIn(0001);
            popupStatus = 1; // and set value to 1
        }
    }
 
    function disablePopup() {
            if (popupStatus == 1) { // if value is 1, close popup
                $("#toPopup").fadeOut("normal");
                $("#backgroundPopup").fadeOut("normal");
                popupStatus = 0; // and set value to 0
            }
        }
        /************** end: functions. **************/
}); // jQuery End
 
$(function() {
    $('#slides').slidesjs({
        width: 940,
        height: 528,
        navigation: false
 
    });
 
    $('#slides1').slidesjs({
        width: 940,
        height: 528,
        navigation: false,
 
    });
 
    /*
      To have multiple slideshows on the same page
      they just need to have separate IDs
    */
    $('#slides2').slidesjs({
        width: 940,
        height: 528,
        navigation: false,
        start: 3,
 
    });
 
});
 
var isVisible = true;
var lastSensor06 = false;
var lastSensor05 = false;
var lastSensor04 = false;
var lastSensor03 = false;
var lastSensor02 = false;
var lastSensor01 = false;
 
function relayOn() {
    if (isVisible == false) {
        //console.log('turned page');
        return
    } else {
        isVisible = false;
        $('#intro').css("visibility", "hidden");
        console.log('relayOn');

        // $('#slides1').slidesjs({
        // width: 940,
        // height: 528,
        // navigation: true,
        // });

    }
}
 
function relayOff() {
    if (isVisible == true) {
        return
    } else {
        isVisible = true;
        $('#intro').css("visibility", "visible");
        console.log('relayOff');
    }
}
 
function relay1On() {
    $('#alphabet').css("visibility", "visible");
    console.log('relay1On');

    //$('#audio').append('<embed id="embed_player" src="audio/zod.m4a" autostart="true" hidden="true"></embed>');
    console.log("audio on");
 
 
}
 
function relay1Off() {
    $('#alphabet').css("visibility", "hidden");
    console.log('relay1Off');

    console.log("audio off");
 
}
 
// function relay2On() {
 
//     console.log("audio off");
// }
 
// function relay2Off() {
 
//     $('#audio').append('<embed id="embed_player" src="audio/zod.m4a" autostart="true" hidden="true"></embed>');
//     console.log("audio on");
//     $('#alphabet').css("visibility", "visible");
 
// }
 
 
 
//node.js socket io
var socket = io.connect('http://localhost:8081');

socket.on('sensordata', function(data) {
 
    if (data.lastSensor01 == 0) {
        //console.log("relayon");
        // if (data.sensor01 == false) {
            relayOn();
        } else if (data.lastSensor01 == 1) {
            relayOff();
           // console.log("relayoff");
        };
 
    //}

    // if (lastSensor02 == data.sensor02) {
 
        if (data.lastSensor02 == 1) {
            relay1On();
            //console.log("relay1on");
        } else if (data.lastSensor02 == 0) {
            relay1Off();
            //console.log("relay1off");
        };
 
    // }

    // if (lastSensor03 == data.sensor03) {
 
    //     if (data.sensor03 == true) {
    //         relay1On();
    //     } else if (data.sensor03 == false) {
    //         relay1Off();
    //     };
 
    // }

    // if (lastSensor04 == data.sensor04) {
 
    //     if (data.sensor04 == true) {
    //         relay1On();
    //     } else if (data.sensor04 == false) {
    //         relay1Off();
    //     };
 
    // }

    // if (lastSensor05 == data.sensor05) {
 
    //     if (data.sensor05 == true) {
    //         relayOn();
    //     } else if (data.sensor05 == false) {
    //         relayOff();
    //     };
 
    // }
 
    
 
    // lastSensor06 = data.sensor06;

    // lastSensor05 = data.sensor05;
    // lastSensor04 = data.sensor04;
    // lastSensor03 = data.sensor03;
    // lastSensor02 = data.sensor02;
    // lastSensor01 = data.sensor01;
 
 
    // Sensor02 = data.sensor02;
    // Sensor03 = data.sensor03;
    // Sensor04 = data.sensor04;
    // Sensor05 = data.sensor05;
    // Sensor06 = data.sensor06;
 
});

